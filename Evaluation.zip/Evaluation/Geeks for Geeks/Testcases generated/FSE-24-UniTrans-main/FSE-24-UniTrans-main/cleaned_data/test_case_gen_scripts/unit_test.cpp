#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
// #include <bits/stdc++.h>
#include <algorithm>
using namespace std;

// TO_FILL_FUNC


int main() {
    try {

        // EXP_OUT

        // ACT_OUT

        // COMPARE

    }catch (std::exception const& e) {
        std::cout << "Runtime Error:\n" << e.what() << std::endl;
    }
    return 0;
}
