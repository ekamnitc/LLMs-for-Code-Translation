#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
// #include <bits/stdc++.h>
#include <algorithm>
using namespace std;

//TO_FILL_FUNC


int main() {

//TO_FILL_EXEC


    return 0;
}
