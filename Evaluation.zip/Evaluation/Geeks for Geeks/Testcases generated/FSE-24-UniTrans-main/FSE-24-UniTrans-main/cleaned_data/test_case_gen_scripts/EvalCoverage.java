import java.util.*;
import java.util.stream.*;
import java.lang.*;
public class EvalCoverage{
// TO_FILL_FUNC

public static void main(String args[]) {
        // TO_FILL_EXEC
}
}
