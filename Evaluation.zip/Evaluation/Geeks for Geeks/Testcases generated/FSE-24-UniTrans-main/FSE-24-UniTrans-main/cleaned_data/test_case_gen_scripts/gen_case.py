import math
import collections
import heapq
import sys
import random
import itertools
from math import sqrt, radians, sin, cos, asin, floor
from collections import defaultdict
import numpy as np
import array

# TO_FILL_FUNC

if __name__ == '__main__':
    try:
        # TO_FILL_EXEC
    except Exception as e:
        print("exception")
