import java.util.*;
import java.util.stream.*;
import java.lang.*;
public class BASIC_AND_EXTENDED_EUCLIDEAN_ALGORITHMS{


// TO_FILL_FUNC

public static void main(String args[]) {
    try{

        // EXP_OUT

        // ACT_OUT

        // COMPARE

    }catch(Exception e){
        System.out.print("Runtime Error:");
        e.printStackTrace();
    }
}
}
